<?php
/**
 * @package WordPress
 * @subpackage Traveler
 * @since 1.0
 *
 * Payment
 *
 * Created by ShineTheme
 *
 */
?>
<div class="pm-info">
	<p><?php st_the_language('you_will_be_redirected_to_payPal')?></p>
</div>